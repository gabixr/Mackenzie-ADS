// Dados mock do Sistema de Reserva de Hotéis

export interface Hotel {
  id: number;
  name: string;
  city: string;
  state: string;
  address: string;
  stars: number;
  rating: number;
  reviewCount: number;
  priceFrom: number;
  image: string;
  amenities: string[];
  description: string;
}

export interface Room {
  id: number;
  hotelId: number;
  type: string;
  description: string;
  price: number;
  capacity: number;
  amenities: string[];
  image: string;
}

export const hotels: Hotel[] = [
  {
    id: 1,
    name: "Hotel Paulista Center",
    city: "São Paulo",
    state: "SP",
    address: "Av. Paulista, 1000 - Bela Vista",
    stars: 4,
    rating: 8.7,
    reviewCount: 342,
    priceFrom: 280,
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&q=80",
    amenities: ["Wi-Fi", "Estacionamento", "Academia", "Restaurante"],
    description: "Hotel moderno localizado na Avenida Paulista, próximo ao metrô e principais atrações da cidade.",
  },
  {
    id: 2,
    name: "Copacabana Palace Hotel",
    city: "Rio de Janeiro",
    state: "RJ",
    address: "Av. Atlântica, 1702 - Copacabana",
    stars: 5,
    rating: 9.2,
    reviewCount: 891,
    priceFrom: 650,
    image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=600&q=80",
    amenities: ["Wi-Fi", "Piscina", "Spa", "Restaurante", "Bar", "Academia"],
    description: "Ícone do Rio de Janeiro, com vista privilegiada para a Praia de Copacabana e serviço de excelência.",
  },
  {
    id: 3,
    name: "Hotel Recife Plaza",
    city: "Recife",
    state: "PE",
    address: "Rua da Aurora, 225 - Boa Vista",
    stars: 3,
    rating: 7.9,
    reviewCount: 178,
    priceFrom: 180,
    image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=600&q=80",
    amenities: ["Wi-Fi", "Café da Manhã", "Estacionamento"],
    description: "Hotel bem localizado no centro histórico de Recife, ideal para viagens de negócios.",
  },
  {
    id: 4,
    name: "Bourbon Curitiba Business",
    city: "Curitiba",
    state: "PR",
    address: "Rua Cândido Lopes, 102 - Centro",
    stars: 4,
    rating: 8.4,
    reviewCount: 256,
    priceFrom: 320,
    image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=600&q=80",
    amenities: ["Wi-Fi", "Academia", "Restaurante", "Sala de Reuniões", "Estacionamento"],
    description: "Hotel executivo no coração de Curitiba, com estrutura completa para viajantes de negócios.",
  },
  {
    id: 5,
    name: "Pousada Pelourinho",
    city: "Salvador",
    state: "BA",
    address: "Largo do Pelourinho, 45 - Centro Histórico",
    stars: 3,
    rating: 8.1,
    reviewCount: 203,
    priceFrom: 210,
    image: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=600&q=80",
    amenities: ["Wi-Fi", "Café da Manhã", "Terraço"],
    description: "Pousada charmosa no centro histórico de Salvador, a passos do Pelourinho.",
  },
  {
    id: 6,
    name: "Gran Melia Belo Horizonte",
    city: "Belo Horizonte",
    state: "MG",
    address: "Av. do Contorno, 7315 - Lourdes",
    stars: 5,
    rating: 9.0,
    reviewCount: 415,
    priceFrom: 480,
    image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=600&q=80",
    amenities: ["Wi-Fi", "Piscina", "Spa", "Restaurante", "Bar", "Academia", "Estacionamento"],
    description: "O mais sofisticado hotel de Belo Horizonte, com vista panorâmica para a Serra do Curral.",
  },
];

export const rooms: Room[] = [
  // Hotel 1
  { id: 1, hotelId: 1, type: "Quarto Standard", description: "Quarto confortável com cama de casal, ar-condicionado e TV.", price: 280, capacity: 2, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Frigobar"], image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=600&q=80" },
  { id: 2, hotelId: 1, type: "Quarto Superior", description: "Quarto amplo com vista para a cidade e banheira.", price: 380, capacity: 2, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Frigobar", "Banheira"], image: "https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=600&q=80" },
  { id: 3, hotelId: 1, type: "Suíte Executiva", description: "Suíte com sala de estar separada, ideal para viagens de negócios.", price: 520, capacity: 2, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Frigobar", "Sala de estar", "Cofre"], image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?w=600&q=80" },
  // Hotel 2
  { id: 4, hotelId: 2, type: "Quarto Vista Mar", description: "Quarto com vista direta para a Praia de Copacabana.", price: 650, capacity: 2, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Frigobar", "Vista Mar"], image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=600&q=80" },
  { id: 5, hotelId: 2, type: "Suíte Luxo", description: "Suíte luxuosa com varanda privativa e vista panorâmica.", price: 1200, capacity: 2, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Frigobar", "Varanda", "Banheira de hidromassagem"], image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=600&q=80" },
  // Hotel 3
  { id: 6, hotelId: 3, type: "Quarto Standard", description: "Quarto simples e confortável com tudo que você precisa.", price: 180, capacity: 2, amenities: ["Wi-Fi", "TV", "Ar-condicionado"], image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=600&q=80" },
  { id: 7, hotelId: 3, type: "Quarto Triplo", description: "Quarto com cama de casal e cama de solteiro, ideal para famílias.", price: 250, capacity: 3, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Frigobar"], image: "https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=600&q=80" },
  // Hotel 4
  { id: 8, hotelId: 4, type: "Quarto Executivo", description: "Quarto equipado para profissionais em viagem de negócios.", price: 320, capacity: 1, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Mesa de trabalho", "Cofre"], image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?w=600&q=80" },
  { id: 9, hotelId: 4, type: "Suíte Executiva", description: "Suíte com sala de reuniões privativa.", price: 550, capacity: 2, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Sala de reuniões", "Frigobar", "Cofre"], image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=600&q=80" },
  // Hotel 5
  { id: 10, hotelId: 5, type: "Quarto Standard", description: "Quarto aconchegante com decoração colonial.", price: 210, capacity: 2, amenities: ["Wi-Fi", "TV", "Ventilador"], image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=600&q=80" },
  // Hotel 6
  { id: 11, hotelId: 6, type: "Quarto Deluxe", description: "Quarto espaçoso com vista para a cidade.", price: 480, capacity: 2, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Frigobar", "Banheira"], image: "https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=600&q=80" },
  { id: 12, hotelId: 6, type: "Suíte Premium", description: "Suíte com vista panorâmica para a Serra do Curral.", price: 900, capacity: 2, amenities: ["Wi-Fi", "TV", "Ar-condicionado", "Frigobar", "Varanda", "Banheira de hidromassagem", "Sala de estar"], image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?w=600&q=80" },
];

export const cities = ["São Paulo", "Rio de Janeiro", "Recife", "Curitiba", "Salvador", "Belo Horizonte", "Brasília", "Fortaleza", "Manaus", "Porto Alegre"];

export function searchHotels(destination: string, checkIn: string, checkOut: string, guests: number): Hotel[] {
  if (!destination) return hotels;
  const query = destination.toLowerCase();
  return hotels.filter(h =>
    h.city.toLowerCase().includes(query) ||
    h.name.toLowerCase().includes(query) ||
    h.state.toLowerCase().includes(query)
  );
}

export function getHotelById(id: number): Hotel | undefined {
  return hotels.find(h => h.id === id);
}

export function getRoomsByHotel(hotelId: number): Room[] {
  return rooms.filter(r => r.hotelId === hotelId);
}

export function formatCurrency(value: number): string {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function calculateNights(checkIn: string, checkOut: string): number {
  if (!checkIn || !checkOut) return 1;
  const d1 = new Date(checkIn);
  const d2 = new Date(checkOut);
  const diff = Math.ceil((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff : 1;
}
