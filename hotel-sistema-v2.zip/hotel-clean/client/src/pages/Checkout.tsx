import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { ArrowLeft, CreditCard, QrCode, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Navbar from "@/components/Navbar";
import { getHotelById, rooms, formatCurrency, calculateNights } from "@/lib/data";
import { toast } from "sonner";

export default function Checkout() {
  const { roomId } = useParams<{ roomId: string }>();
  const [location, navigate] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const hotelId = Number(searchParams.get("hotelId"));
  const checkIn = searchParams.get("checkIn") || "";
  const checkOut = searchParams.get("checkOut") || "";
  const guests = searchParams.get("guests") || "2";

  const hotel = getHotelById(hotelId);
  const room = rooms.find(r => r.id === Number(roomId));
  const nights = calculateNights(checkIn, checkOut);

  const [paymentMethod, setPaymentMethod] = useState<"credit" | "pix">("credit");
  const [confirmed, setConfirmed] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", cardNumber: "", cardName: "", cardExpiry: "", cardCvv: "" });

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone) {
      toast.error("Preencha todos os dados pessoais.");
      return;
    }
    if (paymentMethod === "credit" && (!form.cardNumber || !form.cardName || !form.cardExpiry || !form.cardCvv)) {
      toast.error("Preencha todos os dados do cartão.");
      return;
    }
    setConfirmed(true);
  }

  if (!hotel || !room) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 max-w-6xl py-16 text-center text-gray-500">
          <p>Dados de reserva não encontrados.</p>
          <Button className="mt-4" onClick={() => navigate("/")}>Voltar ao início</Button>
        </div>
      </div>
    );
  }

  const subtotal = room.price * nights;
  const taxes = Math.round(subtotal * 0.12);
  const total = subtotal + taxes;

  if (confirmed) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 max-w-lg py-16 text-center">
          <CheckCircle size={56} className="mx-auto text-green-500 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Reserva Confirmada!</h1>
          <p className="text-gray-600 mb-1">Sua reserva foi realizada com sucesso.</p>
          <p className="text-gray-600 mb-6">Um e-mail de confirmação foi enviado para <strong>{form.email}</strong>.</p>
          <div className="bg-white border border-gray-200 rounded-lg p-5 text-left text-sm mb-6">
            <p className="font-semibold text-gray-800 mb-3">Detalhes da Reserva</p>
            <div className="space-y-1 text-gray-600">
              <p><span className="font-medium text-gray-800">Hotel:</span> {hotel.name}</p>
              <p><span className="font-medium text-gray-800">Quarto:</span> {room.type}</p>
              <p><span className="font-medium text-gray-800">Check-in:</span> {checkIn ? new Date(checkIn + "T12:00:00").toLocaleDateString("pt-BR") : "-"}</p>
              <p><span className="font-medium text-gray-800">Check-out:</span> {checkOut ? new Date(checkOut + "T12:00:00").toLocaleDateString("pt-BR") : "-"}</p>
              <p><span className="font-medium text-gray-800">Hóspedes:</span> {guests}</p>
              <p><span className="font-medium text-gray-800">Total pago:</span> {formatCurrency(total)}</p>
            </div>
          </div>
          <Button className="bg-blue-700 hover:bg-blue-800 text-white w-full" onClick={() => navigate("/")}>
            Voltar ao início
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="container mx-auto px-4 max-w-6xl py-6">
        <button onClick={() => navigate(-1 as any)} className="flex items-center gap-1 text-sm text-blue-700 hover:underline mb-4">
          <ArrowLeft size={15} /> Voltar
        </button>
        <h1 className="text-xl font-bold text-gray-900 mb-6">Finalizar Reserva</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form */}
          <div className="lg:col-span-2 space-y-5">
            {/* Personal Data */}
            <div className="bg-white rounded-lg border border-gray-200 p-5">
              <h2 className="font-semibold text-gray-800 mb-4">Dados Pessoais</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label className="text-sm text-gray-700 mb-1">Nome Completo *</Label>
                  <Input name="name" value={form.name} onChange={handleChange} placeholder="Seu nome completo" />
                </div>
                <div>
                  <Label className="text-sm text-gray-700 mb-1">E-mail *</Label>
                  <Input name="email" type="email" value={form.email} onChange={handleChange} placeholder="seu@email.com" />
                </div>
                <div>
                  <Label className="text-sm text-gray-700 mb-1">Telefone *</Label>
                  <Input name="phone" value={form.phone} onChange={handleChange} placeholder="(11) 99999-9999" />
                </div>
              </div>
            </div>

            {/* Payment */}
            <div className="bg-white rounded-lg border border-gray-200 p-5">
              <h2 className="font-semibold text-gray-800 mb-4">Forma de Pagamento</h2>
              <div className="flex gap-3 mb-5">
                <button
                  type="button"
                  onClick={() => setPaymentMethod("credit")}
                  className={`flex items-center gap-2 px-4 py-2 rounded border text-sm font-medium transition-colors ${paymentMethod === "credit" ? "border-blue-700 bg-blue-50 text-blue-700" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}
                >
                  <CreditCard size={15} /> Cartão de Crédito
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod("pix")}
                  className={`flex items-center gap-2 px-4 py-2 rounded border text-sm font-medium transition-colors ${paymentMethod === "pix" ? "border-blue-700 bg-blue-50 text-blue-700" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}
                >
                  <QrCode size={15} /> PIX
                </button>
              </div>

              {paymentMethod === "credit" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <Label className="text-sm text-gray-700 mb-1">Número do Cartão *</Label>
                    <Input name="cardNumber" value={form.cardNumber} onChange={handleChange} placeholder="0000 0000 0000 0000" maxLength={19} />
                  </div>
                  <div className="md:col-span-2">
                    <Label className="text-sm text-gray-700 mb-1">Nome no Cartão *</Label>
                    <Input name="cardName" value={form.cardName} onChange={handleChange} placeholder="Nome como no cartão" />
                  </div>
                  <div>
                    <Label className="text-sm text-gray-700 mb-1">Validade *</Label>
                    <Input name="cardExpiry" value={form.cardExpiry} onChange={handleChange} placeholder="MM/AA" maxLength={5} />
                  </div>
                  <div>
                    <Label className="text-sm text-gray-700 mb-1">CVV *</Label>
                    <Input name="cardCvv" value={form.cardCvv} onChange={handleChange} placeholder="123" maxLength={4} />
                  </div>
                </div>
              )}

              {paymentMethod === "pix" && (
                <div className="text-center py-6 border border-dashed border-gray-300 rounded-lg">
                  <QrCode size={80} className="mx-auto text-gray-400 mb-3" />
                  <p className="text-sm text-gray-600">Após confirmar a reserva, um QR Code PIX será gerado para pagamento.</p>
                </div>
              )}
            </div>
          </div>

          {/* Summary */}
          <div>
            <div className="bg-white rounded-lg border border-gray-200 p-5 sticky top-20">
              <h2 className="font-semibold text-gray-800 mb-4">Resumo da Reserva</h2>
              <img src={room.image} alt={room.type} className="w-full h-32 object-cover rounded mb-3" />
              <p className="font-medium text-gray-900 text-sm">{hotel.name}</p>
              <p className="text-xs text-gray-500 mb-3">{room.type}</p>
              <div className="space-y-1 text-sm text-gray-600 border-t border-gray-100 pt-3">
                {checkIn && <p>Check-in: <span className="font-medium text-gray-800">{new Date(checkIn + "T12:00:00").toLocaleDateString("pt-BR")}</span></p>}
                {checkOut && <p>Check-out: <span className="font-medium text-gray-800">{new Date(checkOut + "T12:00:00").toLocaleDateString("pt-BR")}</span></p>}
                <p>Hóspedes: <span className="font-medium text-gray-800">{guests}</span></p>
                <p>Noites: <span className="font-medium text-gray-800">{nights}</span></p>
              </div>
              <div className="border-t border-gray-100 mt-3 pt-3 space-y-1 text-sm">
                <div className="flex justify-between text-gray-600">
                  <span>{formatCurrency(room.price)} × {nights} noite(s)</span>
                  <span>{formatCurrency(subtotal)}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Taxas e impostos</span>
                  <span>{formatCurrency(taxes)}</span>
                </div>
                <div className="flex justify-between font-bold text-gray-900 text-base pt-2 border-t border-gray-100">
                  <span>Total</span>
                  <span className="text-blue-700">{formatCurrency(total)}</span>
                </div>
              </div>
              <Button
                className="w-full mt-4 bg-blue-700 hover:bg-blue-800 text-white"
                onClick={handleSubmit}
              >
                Confirmar Reserva
              </Button>
              <p className="text-xs text-gray-400 text-center mt-2">Seus dados são protegidos com criptografia SSL</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
