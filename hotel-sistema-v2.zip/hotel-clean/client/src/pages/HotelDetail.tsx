import { useLocation, useParams } from "wouter";
import { ArrowLeft, MapPin, Star, Wifi, Car, Dumbbell, Utensils, Waves, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import { getHotelById, getRoomsByHotel, formatCurrency, calculateNights } from "@/lib/data";

const amenityIcons: Record<string, React.ReactNode> = {
  "Wi-Fi": <Wifi size={14} />,
  "Estacionamento": <Car size={14} />,
  "Academia": <Dumbbell size={14} />,
  "Restaurante": <Utensils size={14} />,
  "Piscina": <Waves size={14} />,
  "Spa": <Sparkles size={14} />,
};

export default function HotelDetail() {
  const { id } = useParams<{ id: string }>();
  const [location, navigate] = useLocation();

  // Parse query params
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const checkIn = searchParams.get("checkIn") || "";
  const checkOut = searchParams.get("checkOut") || "";
  const guests = searchParams.get("guests") || "2";

  const hotel = getHotelById(Number(id));
  const rooms = getRoomsByHotel(Number(id));
  const nights = calculateNights(checkIn, checkOut);

  if (!hotel) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="container mx-auto px-4 max-w-6xl py-16 text-center text-gray-500">
          <p>Hotel não encontrado.</p>
          <Button className="mt-4" onClick={() => navigate("/")}>Voltar</Button>
        </div>
      </div>
    );
  }

  function renderStars(count: number) {
    return Array.from({ length: 5 }, (_, i) => (
      <Star key={i} size={14} className={i < count ? "text-yellow-400 fill-yellow-400" : "text-gray-300"} />
    ));
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="container mx-auto px-4 max-w-6xl py-6">
        {/* Back */}
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-1 text-sm text-blue-700 hover:underline mb-4"
        >
          <ArrowLeft size={15} /> Voltar para resultados
        </button>

        {/* Hotel Header */}
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden mb-6">
          <img src={hotel.image} alt={hotel.name} className="w-full h-56 object-cover" />
          <div className="p-5">
            <div className="flex items-start justify-between flex-wrap gap-3">
              <div>
                <h1 className="text-xl font-bold text-gray-900">{hotel.name}</h1>
                <p className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                  <MapPin size={13} /> {hotel.address} — {hotel.city}, {hotel.state}
                </p>
                <div className="flex items-center gap-1 mt-2">{renderStars(hotel.stars)}</div>
              </div>
              <div className="flex items-center gap-2">
                <span className="bg-blue-700 text-white font-bold px-3 py-1 rounded text-sm">
                  {hotel.rating.toFixed(1)}
                </span>
                <span className="text-xs text-gray-500">{hotel.reviewCount} avaliações</span>
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-3">{hotel.description}</p>
            <div className="flex flex-wrap gap-2 mt-4">
              {hotel.amenities.map(a => (
                <div key={a} className="flex items-center gap-1 text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                  {amenityIcons[a] || null} {a}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Search summary */}
        {checkIn && checkOut && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg px-4 py-3 mb-5 text-sm text-blue-800 flex flex-wrap gap-4">
            <span>Check-in: <strong>{new Date(checkIn + "T12:00:00").toLocaleDateString("pt-BR")}</strong></span>
            <span>Check-out: <strong>{new Date(checkOut + "T12:00:00").toLocaleDateString("pt-BR")}</strong></span>
            <span>Hóspedes: <strong>{guests}</strong></span>
            <span>Estadia: <strong>{nights} noite(s)</strong></span>
          </div>
        )}

        {/* Rooms */}
        <h2 className="text-base font-semibold text-gray-800 mb-3">Tipos de Quartos Disponíveis</h2>
        <div className="space-y-4">
          {rooms.map(room => (
            <div key={room.id} className="bg-white rounded-lg border border-gray-200 overflow-hidden flex flex-col md:flex-row">
              <img
                src={room.image}
                alt={room.type}
                className="w-full md:w-52 h-40 md:h-auto object-cover flex-shrink-0"
              />
              <div className="p-4 flex flex-col justify-between flex-1">
                <div>
                  <div className="flex items-start justify-between flex-wrap gap-2">
                    <div>
                      <h3 className="font-semibold text-gray-900">{room.type}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">Capacidade: {room.capacity} pessoa(s)</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">{room.description}</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {room.amenities.map(a => (
                      <Badge key={a} variant="secondary" className="text-xs">{a}</Badge>
                    ))}
                  </div>
                </div>
                <div className="flex items-end justify-between mt-4 pt-3 border-t border-gray-100">
                  <div>
                    <p className="text-lg font-bold text-blue-700">{formatCurrency(room.price)}<span className="text-xs font-normal text-gray-400"> /noite</span></p>
                    {nights > 1 && (
                      <p className="text-xs text-gray-500">Total ({nights} noites): <strong>{formatCurrency(room.price * nights)}</strong></p>
                    )}
                  </div>
                  <Button
                    className="bg-blue-700 hover:bg-blue-800 text-white"
                    onClick={() =>
                      navigate(
                        `/checkout/${room.id}?hotelId=${hotel.id}&checkIn=${checkIn}&checkOut=${checkOut}&guests=${guests}`
                      )
                    }
                  >
                    Reservar Agora
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
