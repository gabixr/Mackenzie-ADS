import { CalendarX } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import { useLocation } from "wouter";

export default function MyReservations() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="container mx-auto px-4 max-w-6xl py-12">
        <h1 className="text-xl font-bold text-gray-900 mb-6">Minhas Reservas</h1>
        <div className="bg-white rounded-lg border border-gray-200 py-16 text-center">
          <CalendarX size={48} className="mx-auto text-gray-300 mb-4" />
          <p className="text-gray-500 text-base">Você ainda não possui reservas.</p>
          <p className="text-gray-400 text-sm mt-1 mb-6">Pesquise hotéis e faça sua primeira reserva!</p>
          <Button className="bg-blue-700 hover:bg-blue-800 text-white" onClick={() => navigate("/")}>
            Buscar Hotéis
          </Button>
        </div>
      </div>
    </div>
  );
}
