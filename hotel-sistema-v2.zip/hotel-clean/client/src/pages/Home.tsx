import { useState } from "react";
import { useLocation } from "wouter";
import { Search, MapPin, Calendar, Users, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import { hotels, searchHotels, formatCurrency, cities } from "@/lib/data";

export default function Home() {
  const [, navigate] = useLocation();
  const [destination, setDestination] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState(2);
  const [results, setResults] = useState(hotels);
  const [searched, setSearched] = useState(false);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    const found = searchHotels(destination, checkIn, checkOut, guests);
    setResults(found);
    setSearched(true);
  }

  function renderStars(count: number) {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        size={13}
        className={i < count ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}
      />
    ));
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Hero / Search Section */}
      <div className="bg-blue-700 text-white py-10">
        <div className="container mx-auto px-4 max-w-6xl">
          <h1 className="text-2xl font-semibold mb-1">Encontre o hotel ideal para sua viagem</h1>
          <p className="text-blue-200 text-sm mb-6">Pesquise entre centenas de hotéis em todo o Brasil</p>

          <form onSubmit={handleSearch} className="bg-white rounded-lg p-4 shadow-md">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <Label className="text-gray-700 text-xs font-medium mb-1 flex items-center gap-1">
                  <MapPin size={12} /> Destino
                </Label>
                <Input
                  placeholder="Cidade ou hotel"
                  value={destination}
                  onChange={e => setDestination(e.target.value)}
                  list="cities-list"
                  className="text-gray-900"
                />
                <datalist id="cities-list">
                  {cities.map(c => <option key={c} value={c} />)}
                </datalist>
              </div>
              <div>
                <Label className="text-gray-700 text-xs font-medium mb-1 flex items-center gap-1">
                  <Calendar size={12} /> Check-in
                </Label>
                <Input
                  type="date"
                  value={checkIn}
                  onChange={e => setCheckIn(e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                  className="text-gray-900"
                />
              </div>
              <div>
                <Label className="text-gray-700 text-xs font-medium mb-1 flex items-center gap-1">
                  <Calendar size={12} /> Check-out
                </Label>
                <Input
                  type="date"
                  value={checkOut}
                  onChange={e => setCheckOut(e.target.value)}
                  min={checkIn || new Date().toISOString().split("T")[0]}
                  className="text-gray-900"
                />
              </div>
              <div>
                <Label className="text-gray-700 text-xs font-medium mb-1 flex items-center gap-1">
                  <Users size={12} /> Hóspedes
                </Label>
                <div className="flex items-center gap-2">
                  <Input
                    type="number"
                    min={1}
                    max={10}
                    value={guests}
                    onChange={e => setGuests(Number(e.target.value))}
                    className="text-gray-900"
                  />
                  <Button type="submit" className="bg-blue-700 hover:bg-blue-800 text-white px-4 whitespace-nowrap">
                    <Search size={15} className="mr-1" /> Buscar
                  </Button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>

      {/* Results */}
      <div className="container mx-auto px-4 max-w-6xl py-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-800">
            {searched
              ? results.length > 0
                ? `${results.length} hotel(is) encontrado(s)${destination ? ` para "${destination}"` : ""}`
                : `Nenhum hotel encontrado para "${destination}"`
              : "Hotéis disponíveis"}
          </h2>
          <span className="text-sm text-gray-500">Ordenar por: <span className="font-medium text-gray-700">Relevância</span></span>
        </div>

        {results.length === 0 && (
          <div className="text-center py-16 text-gray-500">
            <MapPin size={40} className="mx-auto mb-3 text-gray-300" />
            <p className="text-base">Nenhum hotel encontrado.</p>
            <p className="text-sm mt-1">Tente outro destino ou datas diferentes.</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {results.map(hotel => (
            <div
              key={hotel.id}
              className="bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => navigate(`/hotel/${hotel.id}?checkIn=${checkIn}&checkOut=${checkOut}&guests=${guests}`)}
            >
              <div className="relative">
                <img
                  src={hotel.image}
                  alt={hotel.name}
                  className="w-full h-44 object-cover"
                />
                <div className="absolute top-2 right-2 bg-white text-blue-700 text-xs font-semibold px-2 py-1 rounded shadow">
                  {hotel.stars}★
                </div>
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between mb-1">
                  <h3 className="font-semibold text-gray-900 text-sm leading-tight">{hotel.name}</h3>
                </div>
                <p className="text-xs text-gray-500 flex items-center gap-1 mb-2">
                  <MapPin size={11} /> {hotel.city}, {hotel.state}
                </p>
                <div className="flex items-center gap-1 mb-2">
                  {renderStars(hotel.stars)}
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <span className="bg-blue-700 text-white text-xs font-bold px-2 py-0.5 rounded">
                    {hotel.rating.toFixed(1)}
                  </span>
                  <span className="text-xs text-gray-500">{hotel.reviewCount} avaliações</span>
                </div>
                <div className="flex flex-wrap gap-1 mb-3">
                  {hotel.amenities.slice(0, 3).map(a => (
                    <Badge key={a} variant="secondary" className="text-xs px-2 py-0">{a}</Badge>
                  ))}
                  {hotel.amenities.length > 3 && (
                    <Badge variant="secondary" className="text-xs px-2 py-0">+{hotel.amenities.length - 3}</Badge>
                  )}
                </div>
                <div className="border-t border-gray-100 pt-3 flex items-end justify-between">
                  <div>
                    <span className="text-xs text-gray-400">a partir de</span>
                    <p className="text-base font-bold text-blue-700">{formatCurrency(hotel.priceFrom)}</p>
                    <span className="text-xs text-gray-400">por noite</span>
                  </div>
                  <Button size="sm" className="bg-blue-700 hover:bg-blue-800 text-white text-xs">
                    Ver quartos
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
